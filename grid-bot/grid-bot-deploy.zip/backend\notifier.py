"""Telegram-уведомления. Вызовы fire-and-forget, не должны ронять бота."""

import logging
from typing import Optional

import httpx

from .config import settings

log = logging.getLogger("notifier")


def send_telegram(text: str) -> None:
    token = settings.telegram_bot_token
    chat_id = settings.telegram_chat_id
    if not token or not chat_id:
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        # короткий таймаут чтобы не блокировать торговый цикл
        with httpx.Client(timeout=5.0) as c:
            c.post(url, json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            })
    except Exception as exc:
        log.warning("telegram send failed: %s", exc)


def notify_fill(bot_id: int, symbol: str, side: str, price: float,
                qty: float, realized: float, open_count: int) -> None:
    emoji = "🟢" if side == "sell" else "🔵"
    pnl_str = (f"<b>P&L: {'+' if realized >= 0 else ''}{realized:.4f} USDT</b>"
               if realized != 0 else "")
    text = (
        f"{emoji} <b>Bot #{bot_id}</b> {symbol}\n"
        f"{side.upper()} filled @ <code>{price}</code>\n"
        f"Qty: <code>{qty}</code>\n"
        f"{pnl_str}\n"
        f"Open: {open_count}"
    )
    send_telegram(text)


def notify_started(bot_id: int, symbol: str, levels: int,
                   lower: float, upper: float) -> None:
    text = (
        f"▶️ <b>Bot #{bot_id}</b> запущен\n"
        f"{symbol}, {levels} уровней\n"
        f"Диапазон: <code>{lower}</code> – <code>{upper}</code>"
    )
    send_telegram(text)


def notify_stopped(bot_id: int, realized_pnl: float) -> None:
    text = (
        f"⏹ <b>Bot #{bot_id}</b> остановлен\n"
        f"Realized P&L: <b>{realized_pnl:+.4f} USDT</b>"
    )
    send_telegram(text)


def notify_error(bot_id: int, error: str) -> None:
    text = f"⚠️ <b>Bot #{bot_id}</b> ошибка:\n<code>{error[:300]}</code>"
    send_telegram(text)
