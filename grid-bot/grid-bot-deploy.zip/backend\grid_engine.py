"""Grid trading engine.

Логика:
- Делим диапазон [lower_price, upper_price] на N равных уровней.
- На каждом уровне НИЖЕ текущей цены ставим лимитный BUY.
- На каждом уровне ВЫШЕ текущей цены ставим лимитный SELL.
- Когда BUY исполняется — над ним ставим SELL на следующем уровне.
- Когда SELL исполняется — под ним ставим BUY на следующем уровне.
- Прибыль = step_price * amount на каждой паре сделок (минус комиссии).
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import ccxt

from .config import settings
from .exchange import (
    bybit_cancel_all,
    bybit_fetch_order,
    bybit_place_order,
    fetch_market_meta,
    fmt_step,
    make_client,
    round_step,
)
from .notifier import (
    notify_error,
    notify_fill,
    notify_started,
    notify_stopped,
)
from .storage import (
    find_oldest_unmatched_buy as _find_oldest_unmatched_buy,
    get_api_key,
    get_conn,
    update_order_fill as _update_fill,
)

log = logging.getLogger("grid")


@dataclass
class GridLevel:
    index: int
    price: float
    side: str  # 'buy' | 'sell'


class GridBot:
    """Один экземпляр grid-бота для одной пары на одной бирже."""

    def __init__(self, bot_id: int):
        self.bot_id = bot_id
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self.client: Optional[ccxt.Exchange] = None
        self.cfg: dict = {}
        self.market_meta: dict = {}

    # ------------- lifecycle -------------

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name=f"grid-{self.bot_id}")

    async def stop(self, cancel_orders: bool = True) -> None:
        self._stop.set()
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=10)
            except asyncio.TimeoutError:
                self._task.cancel()
        if cancel_orders and self.client and self.cfg:
            try:
                if self.client.id == "bybit":
                    await asyncio.to_thread(
                        bybit_cancel_all, self.client, self.cfg["symbol"]
                    )
                else:
                    await asyncio.to_thread(
                        self.client.cancel_all_orders, self.cfg["symbol"]
                    )
            except Exception as exc:
                log.warning("cancel_all_orders failed: %s", exc)
        _set_status(self.bot_id, "stopped")
        # Уведомление о стопе с финальным P&L
        with get_conn() as conn:
            r = conn.execute(
                "SELECT realized_pnl FROM grid_bots WHERE id=?",
                (self.bot_id,),
            ).fetchone()
        if r:
            notify_stopped(self.bot_id, float(r["realized_pnl"]))

    # ------------- core loop -------------

    async def _run(self) -> None:
        try:
            self._load()
            self._connect()
            await asyncio.to_thread(self._place_initial_grid)
            _set_status(self.bot_id, "running", started=True)
            notify_started(
                self.bot_id, self.cfg["symbol"], int(self.cfg["grid_levels"]),
                float(self.cfg["lower_price"]), float(self.cfg["upper_price"]),
            )

            while not self._stop.is_set():
                try:
                    await asyncio.to_thread(self._poll_orders)
                except Exception as exc:
                    log.exception("poll error: %s", exc)
                # Bybit/OKX дают rate-limit 5–10 req/sec — 4 секунды это безопасно
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=4)
                except asyncio.TimeoutError:
                    pass
        except Exception as exc:
            log.exception("bot %s crashed: %s", self.bot_id, exc)
            _set_status(self.bot_id, "error", error=str(exc))
            notify_error(self.bot_id, str(exc))

    # ------------- helpers -------------

    def _load(self) -> None:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT * FROM grid_bots WHERE id = ?", (self.bot_id,)
            ).fetchone()
        if not row:
            raise RuntimeError(f"bot {self.bot_id} not found")
        self.cfg = dict(row)

    def _connect(self) -> None:
        rec = get_api_key(self.cfg["api_key_id"])
        if not rec:
            raise RuntimeError("API ключ не найден")
        self.client = make_client(
            rec["exchange"], rec["api_key"], rec["api_secret"],
            rec["passphrase"], rec["testnet"],
        )
        # На bybit demo load_markets падает (не поддерживается); грузим только
        # для остальных бирж
        if self.client.id != "bybit":
            self.client.load_markets()
        # Метаданные пары: minQty, step, tickSize
        self.market_meta = fetch_market_meta(self.client, self.cfg["symbol"])

    def _levels(self) -> list[float]:
        n = int(self.cfg["grid_levels"])
        lo = float(self.cfg["lower_price"])
        hi = float(self.cfg["upper_price"])
        step = (hi - lo) / (n - 1)
        return [round(lo + i * step, 8) for i in range(n)]

    def _amount_per_order(self, price: float) -> float:
        # order_size_quote — размер одного ордера в USDT
        return float(self.cfg["order_size_quote"]) / price

    def _place_initial_grid(self) -> None:
        assert self.client
        symbol = self.cfg["symbol"]
        # Текущая цена через v5 (работает на demo)
        from .exchange import fetch_ticker
        ticker = fetch_ticker(self.client, symbol)
        last = float(ticker["last"])

        levels = self._levels()
        meta = self.market_meta
        min_qty = max(meta.get("min_qty", 0), 0)
        qty_step = meta.get("qty_step") or 0.000001
        tick = meta.get("tick_size") or 0.01

        for price in levels:
            side = "buy" if price < last else "sell"
            raw_amount = self._amount_per_order(price)
            amount = round_step(raw_amount, qty_step)
            if amount < min_qty:
                amount = min_qty
            price_r = round_step(price, tick)
            try:
                if self.client.id == "bybit":
                    order = bybit_place_order(
                        self.client, symbol, side, amount, price_r,
                        qty_step=qty_step, tick_size=tick,
                    )
                else:
                    amount = float(self.client.amount_to_precision(symbol, amount))
                    price_r = float(self.client.price_to_precision(symbol, price_r))
                    order = self.client.create_order(
                        symbol, "limit", side, amount, price_r
                    )
                _save_order(self.bot_id, order, side, price_r, amount)
            except Exception as exc:
                log.warning("place %s @ %s failed: %s", side, price_r, exc)

    def _poll_orders(self) -> None:
        """Раз в N секунд: смотрим что закрылось, ставим противоположный ордер."""
        assert self.client
        symbol = self.cfg["symbol"]

        # все наши открытые ордера (по записям из БД)
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM bot_orders WHERE bot_id = ? AND status = 'open'",
                (self.bot_id,),
            ).fetchall()

        if not rows:
            return

        # тянем их статусы пакетом
        for r in rows:
            if not r["exchange_order_id"]:
                continue
            try:
                if self.client.id == "bybit":
                    o = bybit_fetch_order(self.client, r["exchange_order_id"], symbol)
                else:
                    o = self.client.fetch_order(r["exchange_order_id"], symbol)
            except Exception as exc:
                log.warning("fetch_order failed: %s", exc)
                continue
            status = o.get("status")
            if status == "closed":
                self._on_fill(r, o)
            elif status == "canceled":
                _mark_canceled(r["id"])

    def _on_fill(self, filled_row: sqlite3.Row, order: dict) -> None:
        """Когда ордер исполнился — ставим встречный + считаем точный P&L."""
        assert self.client
        symbol = self.cfg["symbol"]
        levels = self._levels()
        step = levels[1] - levels[0]

        side = filled_row["side"]
        # Реальные данные fill из биржи (для ccxt.fetch_order — другие ключи)
        if self.client.id == "bybit":
            fill_price = float(order.get("fill_price") or filled_row["price"])
            fill_qty = float(order.get("fill_qty") or filled_row["amount"])
            fee = float(order.get("fee") or 0)
            fee_coin = order.get("fee_coin") or ""
        else:
            fill_price = float(order.get("average") or order.get("price") or filled_row["price"])
            fill_qty = float(order.get("filled") or filled_row["amount"])
            fee_info = order.get("fee") or {}
            fee = float(fee_info.get("cost") or 0)
            fee_coin = fee_info.get("currency") or ""

        realized = 0.0
        pair_buy_id: Optional[int] = None

        if side == "sell":
            # FIFO: ищем самый старый buy без пары и привязываем к нему
            pair = _find_oldest_unmatched_buy(self.bot_id)
            if pair:
                pair_buy_id = pair["id"]
                buy_price = float(pair["fill_price"] or 0)
                buy_qty = float(pair["fill_qty"] or 0)
                buy_fee = float(pair["fee"] or 0)
                qty = min(fill_qty, buy_qty) if buy_qty else fill_qty
                realized = (fill_price - buy_price) * qty - fee - buy_fee

        # Сохраняем fill в БД (и обновляем realized_pnl)
        _update_fill(filled_row["id"], fill_price, fill_qty, fee, fee_coin,
                     realized, pair_buy_id)
        if realized != 0:
            _add_pnl(self.bot_id, realized)

        # Встречный ордер
        if side == "buy":
            new_side = "sell"
            new_price = fill_price + step
        else:
            new_side = "buy"
            new_price = fill_price - step

        # Не выходим за диапазон сетки
        lo = float(self.cfg["lower_price"])
        hi = float(self.cfg["upper_price"])
        if new_price < lo or new_price > hi:
            log.info("bot %s: skip counter %s @ %s (out of range)",
                     self.bot_id, new_side, new_price)
            return

        try:
            qty_step = self.market_meta.get("qty_step") or 0.000001
            tick = self.market_meta.get("tick_size") or 0.01
            new_amount = round_step(fill_qty, qty_step)
            new_price = round_step(new_price, tick)
            if self.client.id == "bybit":
                new_order = bybit_place_order(
                    self.client, symbol, new_side, new_amount, new_price,
                    qty_step=qty_step, tick_size=tick,
                )
            else:
                new_price = float(self.client.price_to_precision(symbol, new_price))
                new_amount = float(self.client.amount_to_precision(symbol, new_amount))
                new_order = self.client.create_order(
                    symbol, "limit", new_side, new_amount, new_price
                )
            _save_order(self.bot_id, new_order, new_side, new_price, new_amount)
            log.info("bot %s: %s @ %s -> %s @ %s, pnl=%.4f",
                     self.bot_id, side, fill_price, new_side, new_price, realized)
        except Exception as exc:
            log.warning("place counter order failed: %s", exc)

        # Telegram-уведомление о fill
        with get_conn() as conn:
            open_cnt = conn.execute(
                "SELECT COUNT(*) c FROM bot_orders WHERE bot_id=? AND status='open'",
                (self.bot_id,),
            ).fetchone()["c"]
        notify_fill(self.bot_id, symbol, side, fill_price, fill_qty,
                    realized, int(open_cnt))


# -------- DB helpers --------

def _save_order(bot_id: int, order: dict, side: str, price: float, amount: float) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO bot_orders
               (bot_id, exchange_order_id, side, price, amount, status, created_at)
               VALUES (?, ?, ?, ?, ?, 'open', ?)""",
            (bot_id, order.get("id"), side, price, amount, datetime.utcnow().isoformat()),
        )


def _mark_canceled(order_row_id: int) -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE bot_orders SET status='canceled' WHERE id=?",
            (order_row_id,),
        )


# _mark_filled больше не используется напрямую — fill идёт через update_order_fill
def _add_pnl(bot_id: int, amount: float) -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE grid_bots SET realized_pnl = realized_pnl + ? WHERE id = ?",
            (amount, bot_id),
        )


def _set_status(bot_id: int, status: str, started: bool = False, error: str = "") -> None:
    with get_conn() as conn:
        if started:
            conn.execute(
                "UPDATE grid_bots SET status=?, started_at=? WHERE id=?",
                (status, datetime.utcnow().isoformat(), bot_id),
            )
        else:
            conn.execute("UPDATE grid_bots SET status=? WHERE id=?", (status, bot_id))


# -------- registry of running bots --------

_registry: dict[int, GridBot] = {}


def get_bot(bot_id: int) -> GridBot:
    bot = _registry.get(bot_id)
    if not bot:
        bot = GridBot(bot_id)
        _registry[bot_id] = bot
    return bot


async def stop_all() -> None:
    for bot in list(_registry.values()):
        await bot.stop(cancel_orders=False)
    _registry.clear()
